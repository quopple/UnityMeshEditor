﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class cs_MeshOpt_V2 : MonoBehaviour {
    public Camera m_pCamera;

	// Use this for initialization
	void Start () {
		
	}


    //1.生成一个操纵柄
    private bool m_bMouseBtnDown = false;
    private Transform m_tfOperator;
    void Update()
    {
        if (true == Input.GetKeyDown(KeyCode.Mouse0))
        {
            RaycastHit t_rayHit;
            Ray t_Ray = m_pCamera.ScreenPointToRay(Input.mousePosition);
            if(true == Physics.Raycast(t_Ray, out t_rayHit, 1000))
            {
                //Debug.Log(t_rayHit.collider.name);
                Transform t_tfPlane = t_rayHit.transform;
                //
                //Debug.Log(t_rayHit.point);
                Vector3 t_vec3HitPos_PlaneSpace = t_tfPlane.InverseTransformPoint(t_rayHit.point);
                //Debug.Log(t_vec3HitPos_PlaneSpace);
                //
                if (false == m_bMouseBtnDown)
                {
                    m_bMouseBtnDown = true;
                    //1.1.1.生成一个操纵柄
                    GameObject t_goOperator = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    m_tfOperator = t_goOperator.GetComponent<Transform>();
                    //
                    m_tfOperator.parent = t_tfPlane;
                    m_tfOperator.position = t_vec3HitPos_PlaneSpace;
                    m_tfOperator.rotation = Quaternion.identity;
                    m_tfOperator.localScale = Vector3.one;
                    //
                    //Debug.Log("Create");
                }

                ///1.2.拖动球
                ///对应会有顶点移动
              //  t_rayHit.collider.gameObject.GetComponent<MeshFilter>().mesh;


            }




        }

        if (true == m_bMouseBtnDown)
        {
            if (true == Input.GetKeyUp(KeyCode.Mouse0))
            {
                //1.1.2.删除操纵柄
                if (null != m_tfOperator)
                {
                    Destroy(m_tfOperator.gameObject);
                }
                m_tfOperator = null;
                m_bMouseBtnDown = false;
            }
        }

    }
}
