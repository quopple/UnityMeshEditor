﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(MeshOperator5))]
[CanEditMultipleObjects]
public class MeshEditorV5 : Editor
{
    void OnSceneGUI()
    {
        MeshOperator5 t_meshOp = target as MeshOperator5;
        if ( t_meshOp.m_bIsOn )
        {
            HandleUtility.AddDefaultControl(0);     //锁定操作游戏对象
            EventProcess(t_meshOp);                 
            if (t_meshOp.m_bIsEditing)              //处于编辑状态才显示操作控件
            {
                DrawControlUI(t_meshOp);            //在scene视图绘制ui
                ChangeMesh(t_meshOp);
            }
            if (GUI.changed)
                EditorUtility.SetDirty(target);
        }
    }


    public override void OnInspectorGUI()
    {
        MeshOperator5 t_meshOp = target as MeshOperator5;
        GUIStyle boolBtnOn     = new GUIStyle(GUI.skin.GetStyle("Button"));//得到Button样式
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        t_meshOp.m_bIsOn = GUILayout.Toggle( t_meshOp.m_bIsOn, EditorGUIUtility.IconContent("EditCollider"), boolBtnOn, GUILayout.Width(35), GUILayout.Height(25));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
    }


    private void DrawControlUI(MeshOperator5 t_meshOp)
    {
        Vector3 t_vec3OrgPos   = Selection.activeTransform.position;
        Vector3 t_vec3WorldPos = t_vec3OrgPos + t_meshOp.m_vec3Position;    //将mesh对象坐标系下的编辑顶点坐标转换为世界坐标
        float   t_fStander     = t_meshOp.m_fRadius > 1f ? t_meshOp.m_fRadius : 1f;

        Handles.color = Color.red;
        Handles.DrawWireArc(t_vec3WorldPos + Vector3.up ,    //绘制一个圆圈，表示操作范围
                t_meshOp.transform.up,
                t_meshOp.transform.right,
                360,    
                t_fStander);           
        
        //半径更改句柄
        float t_fNewRadius = Handles.ScaleValueHandle(t_meshOp.m_fRadius+5,
                        t_vec3WorldPos,
                        t_meshOp.transform.rotation,
                        t_fStander*3,
                        Handles.ArrowCap,
                        10);
        t_fNewRadius = Mathf.Abs(t_fNewRadius-5);                       
        if (Mathf.Abs(t_fNewRadius - t_meshOp.m_fRadius) > 0)
        {
            t_meshOp.m_fRadius = t_fNewRadius;
            t_meshOp.m_bIsRangeChanged = true;
        }

        //高度更改句柄
        Vector3 t_vec3Pos = Handles.Slider(
            t_vec3WorldPos, Vector3.up);
        float t_fDh = t_vec3Pos.y - t_meshOp.m_vec3Position.y;
        if (Mathf.Abs(t_fDh) > 0)
        {
            t_meshOp.m_fDh += t_fDh;
            t_meshOp.m_bIsHeightChanged = true;
            t_meshOp.m_vec3Position.y = t_vec3Pos.y;
        }

        //坡度更改句柄
        float t_fSlop = Handles.ScaleSlider(t_meshOp.m_fSlop+5, t_vec3WorldPos, Vector3.forward+Vector3.up, Quaternion.identity, t_fStander*0.4f, 10);
        t_fSlop = Mathf.Abs(t_fSlop-5);
        if (Mathf.Abs(t_fSlop - t_meshOp.m_fSlop) > 0)
        {
            t_meshOp.m_fSlop = t_fSlop;
            t_meshOp.m_bIsSlopChanged = true;
        }

        // GUI相关的绘制需要在Handles的绘制之后，否则会被覆盖掉;  
        GUILayout.BeginArea(new Rect(Screen.width - 120, Screen.height - 100, 110, 100));
        try
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label("radius:");
            t_fNewRadius = float.Parse(GUILayout.TextField(t_meshOp.m_fRadius.ToString()));
            t_fNewRadius = Mathf.Abs(t_fNewRadius);
            if (Mathf.Abs(t_fNewRadius - t_meshOp.m_fRadius) > 0)
            {
                t_meshOp.m_fRadius = t_fNewRadius;
                t_meshOp.m_bIsRangeChanged = true;
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("slop:");
            t_fSlop = float.Parse(GUILayout.TextField( t_meshOp.m_fSlop.ToString()));
            t_fSlop = Mathf.Abs(t_fSlop);
            if (Mathf.Abs(t_fSlop - t_meshOp.m_fSlop) > 0)
            {
                t_meshOp.m_fSlop = t_fSlop;
                t_meshOp.m_bIsSlopChanged = true;
            }
            GUILayout.EndHorizontal();

            GUILayout.Label(t_meshOp.m_vec3Position.ToString() + "\ndH: " +
                t_meshOp.m_fDh.ToString());
        }
        catch (System.Exception e)
        {

        }
        GUILayout.EndArea();
    }


    private void GetPointInRange(MeshOperator5 t_meshOp, Vector3[] t_vec3Vertices, Vector3 center,bool recalCenter = true)
    {
        var ref_dicVerticeInRange = t_meshOp.m_dicVertexIndexInRange;

        float r = t_meshOp.m_fRadius;
        float d = r * 2;
        double rSQ = Math.Pow(r, 2);

        int centerIndex = 0;
        float minDist = float.MaxValue;

        //查找距离点击位置最近的顶点作为编辑点，并把半径内的所有顶点的索引、高度记录起来
        for (int i = 0; i < t_vec3Vertices.Length; ++i)
        {
            float dx = Mathf.Abs(t_vec3Vertices[i].x - center.x);
            float dy = Mathf.Abs(t_vec3Vertices[i].z - center.z);

            if (dx < d && dy < d)   //先以2r为半径过滤一遍
            {
                if ( recalCenter && dx + dy < minDist)
                {
                    minDist = dx + dy;
                    centerIndex = i;
                }
                ref_dicVerticeInRange.Add(i, t_vec3Vertices[i].y);
            }
        }

        //记录编辑的顶点
        if (recalCenter)
        {
            t_meshOp.m_vec3Position.y = 10;
            center = t_meshOp.m_vec3Position = t_vec3Vertices[centerIndex];
        }

        //对前一遍过滤剩下的点过滤离中心点距离在r以上的
        var itr = ref_dicVerticeInRange.GetEnumerator();
        List<int> removeList = new List<int>();
        while (itr.MoveNext())
        {
            double dist = Math.Pow(t_vec3Vertices[itr.Current.Key].x - center.x, 2) +
                Math.Pow(t_vec3Vertices[itr.Current.Key].z - center.z, 2);
            if (dist > rSQ)
            {
                removeList.Add(itr.Current.Key);
                continue;
            }
        }

        foreach (int ele in removeList) ref_dicVerticeInRange.Remove(ele);
    }


    private void ChangeMesh(MeshOperator5 t_meshOp)
    {
        if (!(t_meshOp.m_bIsHeightChanged || t_meshOp.m_bIsRangeChanged || t_meshOp.m_bIsSlopChanged)) return;
        Mesh t_mesh = Selection.activeGameObject.GetComponent<MeshFilter>().sharedMesh;
        Vector3[] t_vec3Vertices = t_mesh.vertices;

        //设置的坡度\范围\高度更改了，要重计算范围内顶点的高度,先恢复初始的高度
        BackUpMesh(t_meshOp ,t_vec3Vertices);

        //编辑半径更改了，要重新查找编辑范围内的顶点
        if(t_meshOp.m_bIsRangeChanged)
        {
            t_meshOp.m_dicVertexIndexInRange.Clear();
            GetPointInRange(t_meshOp, t_vec3Vertices, t_meshOp.m_vec3Position, false);
        }

        //更改范围内的顶点的高度
        float  r   = t_meshOp.m_fRadius;
        double rSQ = Math.Pow(r, 2);
        float opacity = t_meshOp.m_fDh;
        float slop = t_meshOp.m_fSlop;      //坡度，即函数的阶数，决定平滑程度
        var center = t_meshOp.m_vec3Position;
        var itr    = t_meshOp.m_dicVertexIndexInRange.GetEnumerator();
        while (itr.MoveNext())
        {
            double dist = Math.Pow(t_vec3Vertices[itr.Current.Key].x - center.x, 2) + Math.Pow(t_vec3Vertices[itr.Current.Key].z - center.z, 2);
            double dH = opacity * (1 - Math.Pow(dist / rSQ, 0.5 * slop));
            if (slop == 0) dH = opacity;
            t_vec3Vertices[itr.Current.Key].y += (float)dH;
        }

        t_mesh.vertices = t_vec3Vertices;

        //更新状态
        t_meshOp.m_bIsSlopChanged   = false;
        t_meshOp.m_bIsRangeChanged  = false;
        t_meshOp.m_bIsHeightChanged = false;
    }


    private void BackUpMesh(MeshOperator5 t_meshOp,Vector3[] t_vec3Vertices)
    {
        foreach ( var itr in t_meshOp.m_dicVertexIndexInRange )
        {
            t_vec3Vertices[itr.Key].y = itr.Value;
        }
    }


    private void EventProcess(MeshOperator5 t_meshOp)
    {
        Event e = Event.current;


        if (e.type == EventType.KeyUp)
        {
            switch( e.keyCode )
            {
                case KeyCode.CapsLock:      //大写锁定键锁定\解锁当前操作顶点
                    t_meshOp.m_bIsLocked = !t_meshOp.m_bIsLocked;
                    break;
                case KeyCode.Space:         //space键确定修改
                    t_meshOp.Reinit();
                    break;
                case KeyCode.Escape:        //Escape键取消更改
                    Mesh t_mesh = Selection.activeGameObject.GetComponent<MeshFilter>().sharedMesh;
                    Vector3[] t_vec3Vertices = t_mesh.vertices;
                    BackUpMesh(t_meshOp,t_vec3Vertices);
                    t_mesh.vertices = t_vec3Vertices;
                    t_meshOp.Reinit();
                    break;
                default:
                    break;
            }
        }  
        
        //鼠标左键点击选择网格顶点进行编辑
        else if(e.type == EventType.mouseDown && e.button == 0 && !t_meshOp.m_bIsLocked)
        {
            RaycastHit t_rayHit;
            Ray t_Ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);

            if (true == Physics.Raycast(t_Ray, out t_rayHit, int.MaxValue)) //确保是点击在mesh上
            {
                Transform t_tfPlane  = t_rayHit.transform;
                Vector3 t_vec3HistPos_PlaneSpace = t_tfPlane.InverseTransformPoint(t_rayHit.point);

                if( t_vec3HistPos_PlaneSpace == t_meshOp.m_vec3Position )   //点击的是当前编辑顶点，不处理
                {
                    t_meshOp.m_bIsEditing = true;
                    return;
                }

                t_meshOp.Reinit();      //以防止有逻辑路径没有进行清理
                t_meshOp.m_bIsEditing = true;

                Mesh t_mesh = Selection.activeGameObject.GetComponent<MeshFilter>().sharedMesh;
                Vector3[] t_vec3Vertices  = t_mesh.vertices;
                GetPointInRange(t_meshOp, t_vec3Vertices, t_vec3HistPos_PlaneSpace);
            }
        }
    }
}