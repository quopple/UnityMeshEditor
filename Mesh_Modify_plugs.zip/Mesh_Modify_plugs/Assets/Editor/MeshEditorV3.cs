﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(MeshOperator3))]
[CanEditMultipleObjects]
public class MeshEditorV3 : Editor
{

    int mBrushSize = 0;
    int mBrushOpacity = 0;
    float mSlop = 0;

    bool isOn;

    private Dictionary<int, float> verticeIndexsInRange = new Dictionary<int, float>();

    void OnSceneGUI()
    {
        if (isOn)
        {
            MeshOperator();
        }
    }


    public override void OnInspectorGUI()
    {

        GUIStyle boolBtnOn = new GUIStyle(GUI.skin.GetStyle("Button"));//得到Button样式
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        isOn = GUILayout.Toggle(isOn, EditorGUIUtility.IconContent("EditCollider"), boolBtnOn, GUILayout.Width(35), GUILayout.Height(25));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();

        mBrushSize = (int)EditorGUILayout.Slider("Brush Size", mBrushSize, 1, 100);
        mBrushOpacity = (int)EditorGUILayout.Slider("Opacity", mBrushOpacity, -100, 100);
        mSlop = EditorGUILayout.Slider("Slop", mSlop, 0, 10);

    }

    void MeshOperator()
    {
        HandleUtility.AddDefaultControl(0); //锁定操纵模型对象

        Event e = Event.current;
        if (e.type == EventType.MouseDown && e.button == 0) // 鼠标左键按下，直接更改
        {
            RaycastHit t_rayHit;
            Ray t_Ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            if (true == Physics.Raycast(t_Ray, out t_rayHit, int.MaxValue)) //确保是点击在mesh上
            {
                if (verticeIndexsInRange.Count != 0) verticeIndexsInRange.Clear(); //如果inRange map不为0，即当前演示模式已经叠加了高度
                else
                {
                    Transform t_ftPlane = t_rayHit.transform;
                    Vector3 t_vec3HistPos_PlaneSpace = t_ftPlane.InverseTransformPoint(t_rayHit.point);

                    Mesh tMesh = t_rayHit.collider.gameObject.GetComponent<MeshFilter>().sharedMesh;
                    Vector3[] vertices = tMesh.vertices;

                    int r = (mBrushSize + 1) / 2;
                    double rSQ = Math.Pow(r, 2);

                    float minDist = float.MaxValue;
                    int centerIndex = 0;
                    for (int i = 0; i < vertices.Length; ++i)
                    {

                        float dx = Mathf.Abs(vertices[i].x - t_vec3HistPos_PlaneSpace.x);
                        float dy = Mathf.Abs(vertices[i].z - t_vec3HistPos_PlaneSpace.z);

                        if (dx < mBrushSize && dy < mBrushSize)
                        {
                            if (dx + dy < minDist)
                            {
                                minDist = dx + dy;
                                centerIndex = i;
                            }
                            verticeIndexsInRange.Add(i, vertices[i].y);
                        }
                    }

                    foreach (var itr in verticeIndexsInRange)
                    {
                        double dist = Math.Pow(vertices[itr.Key].x - vertices[centerIndex].x, 2) + Math.Pow(vertices[itr.Key].z - vertices[centerIndex].z, 2);
                        if (dist > rSQ) continue;

                        double dH = mBrushOpacity * (1 - Math.Pow(dist / rSQ, 0.5 * mSlop));
                        if (mSlop == 0) dH = mBrushOpacity;
                        vertices[itr.Key].y += (float)dH;
                    }

                    tMesh.vertices = vertices;
                    SceneView.RepaintAll();
                }
            }
        }
        else if (e.type == EventType.MouseMove && e.shift)  //预演模式
        {
            RaycastHit t_rayHit;

            Ray t_Ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            if (true == Physics.Raycast(t_Ray, out t_rayHit, int.MaxValue))
            {
                Transform t_ftPlane = t_rayHit.transform;
                Vector3 t_vec3HistPos_PlaneSpace = t_ftPlane.InverseTransformPoint(t_rayHit.point);

                Mesh tMesh = t_rayHit.collider.gameObject.GetComponent<MeshFilter>().sharedMesh;
                Vector3[] vertices = tMesh.vertices;

                int r = (mBrushSize + 1) / 2;
                double rSQ = Math.Pow(r, 2);

                //恢复前一次更改的顶点高度
                if (verticeIndexsInRange.Count != 0)
                {
                    var iter = verticeIndexsInRange.GetEnumerator();
                    while (iter.MoveNext())
                    {
                        vertices[iter.Current.Key].y = iter.Current.Value;
                    }

                    verticeIndexsInRange.Clear();
                }

                //找出当前范围内的顶点（粗略筛选，以2r半径搜索）和操作的中心点(离点击位置最近的顶点 )并记录
                float minDist = float.MaxValue;
                int centerIndex = 0;
                for (int i = 0; i < vertices.Length; ++i)
                {

                    float dx = Mathf.Abs(vertices[i].x - t_vec3HistPos_PlaneSpace.x);
                    float dy = Mathf.Abs(vertices[i].z - t_vec3HistPos_PlaneSpace.z);

                    if (dx < mBrushSize && dy < mBrushSize)
                    {
                        if (dx + dy < minDist)
                        {
                            minDist = dx + dy;
                            centerIndex = i;
                        }
                        verticeIndexsInRange.Add(i, vertices[i].y);
                    }
                }

                //更改新高度
                var itr = verticeIndexsInRange.GetEnumerator();
                List<int>  removeList = new List<int>() ;
                while( itr.MoveNext() )
                {
                    double dist = Math.Pow(vertices[itr.Current.Key].x - vertices[centerIndex].x, 2) + Math.Pow(vertices[itr.Current.Key].z - vertices[centerIndex].z, 2);
                    if (dist > rSQ)
                    {
                        removeList.Add(itr.Current.Key);
                        continue;
                    }
                    double dH = mBrushOpacity * (1 - Math.Pow(dist / rSQ, 0.5 * mSlop));
                    if (mSlop == 0) dH = mBrushOpacity;
                    vertices[itr.Current.Key].y += (float)dH;
                }

                foreach (int ele in removeList) verticeIndexsInRange.Remove(ele);

                tMesh.vertices = vertices;
                SceneView.RepaintAll();
            }
        }
        else if (e.type == EventType.KeyDown && e.keyCode == KeyCode.LeftControl )
        {
            RaycastHit t_rayHit;
            Ray t_Ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);

            if (true == Physics.Raycast(t_Ray, out t_rayHit, int.MaxValue))
            {

                Transform t_ftPlane = t_rayHit.transform;
                Mesh tMesh = t_rayHit.collider.gameObject.GetComponent<MeshFilter>().sharedMesh;
                Vector3[] vertices = tMesh.vertices;

                //恢复前一次更改的顶点高度
                if (verticeIndexsInRange.Count != 0)
                {
                    var iter = verticeIndexsInRange.GetEnumerator();
                    while (iter.MoveNext())
                    {
                        vertices[iter.Current.Key].y = iter.Current.Value;
                    }

                    verticeIndexsInRange.Clear();
                }
                tMesh.vertices = vertices;

                SceneView.RepaintAll();
            }
        }
    }
}
