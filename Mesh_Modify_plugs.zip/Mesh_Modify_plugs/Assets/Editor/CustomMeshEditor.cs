﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;



[CustomEditor(typeof(MeshOperator))]
[CanEditMultipleObjects]
public class CustomMeshEditor : Editor
{
    int mBrushSize = 0;
    int mBrushOpacity = 0;
    int mSlop = 0;

    bool isOn;


    void OnSceneGUI()
    {
        if (isOn)
        {
            MeshOperator();
        }
    }


    public override void OnInspectorGUI()
    {

        GUIStyle boolBtnOn = new GUIStyle(GUI.skin.GetStyle("Button"));//得到Button样式
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        isOn = GUILayout.Toggle(isOn, EditorGUIUtility.IconContent("EditCollider"), boolBtnOn, GUILayout.Width(35), GUILayout.Height(25));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();

        mBrushSize = (int)EditorGUILayout.Slider("Brush Size", mBrushSize, 1, 100);
        mBrushOpacity = (int)EditorGUILayout.Slider("Opacity", mBrushOpacity, -100, 100);
        mSlop = (int)EditorGUILayout.Slider("Slop", mSlop, 1, 100);

    }

/*
    private double ProjectSigma(int val)
    {
        if (val < 5)
            return (5 - val) * 15 / 4 + 15;      //30--1  -->    0.1--1
        if (val < 20)
            return (20 - val) * 10 / 15 + 5;          //80--30 -->    1--5
        if (val < 70)
            return (70 - val) * 4 / 50 + 1;         //95--80 -->    15--5
        else
            return (100 - val) * 0.9 / 30 + 0.1;        //100--95 -->   30--15
    }
*/
    void MeshOperator()
    {

        HandleUtility.AddDefaultControl(0); //锁定操纵模型对象

        Event e = Event.current;
        if (e.type == EventType.MouseDown && e.button == 0)
        {
            RaycastHit t_rayHit;
            Ray t_Ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            if (true == Physics.Raycast(t_Ray, out t_rayHit, int.MaxValue))
            {
                Transform t_ftPlane = t_rayHit.transform;
                Vector3 t_vec3HistPos_PlaneSpace = t_ftPlane.InverseTransformPoint(t_rayHit.point);

                Mesh tMesh = t_rayHit.collider.gameObject.GetComponent<MeshFilter>().sharedMesh;
                Vector3[] vertices = tMesh.vertices;

                int r = (mBrushSize+1) / 2;
                double rSQ = Math.Pow(r, 2);
                //double sigmaSQ = Math.Pow(ProjectSigma(mSlop), 2);


                float minDist = float.MaxValue;
                int centerIndex = 0;
                List<int> verteicIndexInRange = new List<int>();
                for (int i = 0; i < vertices.Length; ++i)
                {

                    float dx = Mathf.Abs(vertices[i].x - t_vec3HistPos_PlaneSpace.x);
                    float dy = Mathf.Abs(vertices[i].z - t_vec3HistPos_PlaneSpace.z);

                    if (dx < r && dy < r)
                    {
                        if (dx + dy < minDist)
                        {
                            minDist = dx + dy;
                            centerIndex = i;
                        }
                        verteicIndexInRange.Add(i);
                    }
                }

                foreach (int i in verteicIndexInRange)
                {
                    double dist = Math.Pow(vertices[i].x - t_vec3HistPos_PlaneSpace.x,2) + Math.Pow(vertices[i].z - t_vec3HistPos_PlaneSpace.z,2);
                    if (dist > rSQ) continue;
                    double dH = mBrushOpacity *( 1 - dist /rSQ) ;

                    vertices[i].y += (float)dH;
                }

                tMesh.vertices = vertices;
            }
        }
    }
}
