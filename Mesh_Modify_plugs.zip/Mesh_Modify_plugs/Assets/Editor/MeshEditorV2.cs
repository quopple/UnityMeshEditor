﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;


[CustomEditor(typeof(MeshOperator2))]
[CanEditMultipleObjects]
public class MeshEditorV2 : Editor {

    int mBrushSize = 0;
    int mBrushOpacity = 0;
    float mSlop = 0;

    bool isOn;


    void OnSceneGUI()
    {
        if (isOn)
        {
            MeshOperator();
        }
    }


    public override void OnInspectorGUI()
    {

        GUIStyle boolBtnOn = new GUIStyle(GUI.skin.GetStyle("Button"));//得到Button样式
        GUILayout.BeginHorizontal();
        GUILayout.FlexibleSpace();
        isOn = GUILayout.Toggle(isOn, EditorGUIUtility.IconContent("EditCollider"), boolBtnOn, GUILayout.Width(35), GUILayout.Height(25));
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();

        mBrushSize = (int)EditorGUILayout.Slider("Brush Size", mBrushSize, 1, 100);
        mBrushOpacity = (int)EditorGUILayout.Slider("Opacity", mBrushOpacity, -100, 100);
        mSlop = EditorGUILayout.Slider("Slop", mSlop, 0, 10);

    }

    void MeshOperator()
    {
        HandleUtility.AddDefaultControl(0); //锁定操纵模型对象

        Event e = Event.current;
        if (e.type == EventType.MouseDown && e.button == 0)
        {
            RaycastHit t_rayHit;
            Ray t_Ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            if (true == Physics.Raycast(t_Ray, out t_rayHit, int.MaxValue))
            {
                Transform t_ftPlane = t_rayHit.transform;
                Vector3 t_vec3HistPos_PlaneSpace = t_ftPlane.InverseTransformPoint(t_rayHit.point);

                Mesh tMesh = t_rayHit.collider.gameObject.GetComponent<MeshFilter>().sharedMesh;
                Vector3[] vertices = tMesh.vertices;

                int r = (mBrushSize + 1) / 2;
                double rSQ = Math.Pow(r, 2);

                float minDist = float.MaxValue;
                int centerIndex = 0;
                List<int> verteicIndexInRange = new List<int>();
                for (int i = 0; i < vertices.Length; ++i)
                {

                    float dx = Mathf.Abs(vertices[i].x - t_vec3HistPos_PlaneSpace.x);
                    float dy = Mathf.Abs(vertices[i].z - t_vec3HistPos_PlaneSpace.z);

                    if (dx < mBrushSize && dy < mBrushSize)
                    {
                        if (dx + dy < minDist)
                        {
                            minDist = dx + dy;
                            centerIndex = i;
                        }
                        verteicIndexInRange.Add(i);
                    }
                }

                Debug.Log(verteicIndexInRange.Count);
                foreach (int i in verteicIndexInRange)
                {

                    double dist = Math.Pow(vertices[i].x - vertices[centerIndex].x, 2) + Math.Pow(vertices[i].z - vertices[centerIndex].z, 2);
                    if (dist > rSQ) continue;

                    double dH = mBrushOpacity * (1 - Math.Pow( dist / rSQ ,0.5*mSlop) );
                    if (mSlop == 0) dH = mBrushOpacity;
                    vertices[i].y += (float)dH;

                    Debug.Log(i + ":" + vertices[i].x + " " + vertices[i].z + "  dH: " + dH);
                }

                tMesh.vertices = vertices;
            }
        }
    }
}
