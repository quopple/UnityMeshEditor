﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(MeshCollider))]
public class MeshOperator4 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}


    public Vector3 vectorPoint = Vector3.zero;
    public Vector3 vectorPoint2 = Vector3.zero;

    public float shieldArea = 5;
    public Quaternion rot = Quaternion.identity;



}
