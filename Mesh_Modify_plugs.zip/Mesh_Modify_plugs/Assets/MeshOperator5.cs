﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(MeshCollider))]
public class MeshOperator5 : MonoBehaviour {

    [SerializeField]
    public Vector3 m_vec3Position  = Vector3.zero;
    [SerializeField]
    public float m_fDh             = 0f;
    [SerializeField]
    public float m_fRadius         = 0f;
    [SerializeField]
    public float m_fSlop           = 1f;
    [SerializeField]
    public bool  m_bIsOn           = false;
    [SerializeField]
    public bool m_bIsRangeChanged  = false;
    [SerializeField]
    public bool m_bIsSlopChanged   = false;
    [SerializeField]
    public bool m_bIsHeightChanged = false;
    [SerializeField]
    public bool m_bIsLocked        = false;
    [SerializeField]
    public bool m_bIsEditing       = false;

    [SerializeField]
    public Dictionary<int, float> m_dicVertexIndexInRange = new Dictionary<int, float>(); 

    public void RestoreState()
    {
        m_bIsRangeChanged  = false;
        m_bIsSlopChanged   = false;
        m_bIsHeightChanged = false;
        m_bIsLocked  = false;
        m_bIsEditing = false;
    }

    public void ReinitData()
    {
        m_vec3Position = Vector3.zero;
        m_fDh = 0f;
        m_fRadius = 5f;
        m_fSlop = 1f;
    }

    public void Reinit()
    {
        ReinitData();
        RestoreState();
        m_dicVertexIndexInRange.Clear();
    }
}
